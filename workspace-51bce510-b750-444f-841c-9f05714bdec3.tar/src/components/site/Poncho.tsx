"use client";

import { useState } from "react";

type Cam = "moh" | "pixel" | "multicam" | "green" | "blue";

const SWATCHES: { id: Cam; label: string; season: string; desc: string }[] = [
  { id: "moh", label: "Мох", season: "лето/осень", desc: "Лес, трава, листва" },
  { id: "pixel", label: "Пиксель", season: "универсал", desc: "Цифровой паттерн, город" },
  { id: "multicam", label: "Мультикам", season: "универсал", desc: "Смешанный рельеф" },
  { id: "green", label: "Зелёный", season: "лето", desc: "Сплошная растительность" },
  { id: "blue", label: "Синий", season: "город/ночь", desc: "Тёмные операции" },
];

const PREVIEW_BG: Record<Cam, string> = {
  moh: "radial-gradient(circle at 25% 30%,#3d4728 0 18%,transparent 19%),radial-gradient(circle at 70% 60%,#2a3020 0 22%,transparent 23%),radial-gradient(circle at 50% 80%,#4a3d28 0 15%,transparent 16%),#5c6b3c",
  pixel:
    "repeating-conic-gradient(#3d4728 0% 25%,#5c6b3c 0% 50%) 0/24px 24px,#2a3020",
  multicam:
    "radial-gradient(circle at 20% 25%,#8b7355 0 16%,transparent 17%),radial-gradient(circle at 65% 40%,#5c6b3c 0 20%,transparent 21%),radial-gradient(circle at 40% 75%,#a89070 0 14%,transparent 15%),#6b6040",
  green: "linear-gradient(135deg,#5c6b3c,#3d4728)",
  blue: "linear-gradient(135deg,#2a3a55,#16202f)",
};

const SWATCH_ICON_BG: Record<Cam, string> = {
  moh: "#5c6b3c",
  pixel:
    "repeating-conic-gradient(#3d4728 0% 25%,#5c6b3c 0% 50%) 0/6px 6px",
  multicam: "#8b7355",
  green: "#3d4728",
  blue: "#2a3a55",
};

const MATERIALS = ["Оксфорд", "Спанбонд", "Спектра"];

export default function Poncho() {
  const [cam, setCam] = useState<Cam>("moh");

  return (
    <section id="poncho" className="sn-section">
      <header className="reveal mb-16">
        <div className="font-mono-brand text-[0.68rem] text-[var(--olive)] tracking-[3px] uppercase mb-4 flex items-center gap-4 before:content-[''] before:w-[30px] before:h-px before:bg-[var(--olive)]">
          Накидки
        </div>
        <div className="flex justify-between items-end flex-wrap gap-8">
          <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-bold uppercase tracking-[-1px] leading-[1.05]">
            Маскировочные
            <br />
            накидки
          </h2>
          <p className="text-base text-[var(--text2)] max-w-[560px] leading-[1.8]">
            Двусторонние накидки для визуальной маскировки и коррекции теплового
            фона. Пять расцветок под задачу и сезон.
          </p>
        </div>
      </header>

      <div className="reveal grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Preview stage */}
        <div className="relative aspect-[4/3] border border-[var(--border-brand)] overflow-hidden bg-[var(--bg3)] group">
          <span className="absolute top-4 left-4 z-[3] px-3 py-[0.4rem] bg-[rgba(13,13,13,0.8)] border border-[var(--olive)] font-mono-brand text-[0.65rem] text-[var(--olive-light)] tracking-[1px] uppercase">
            ⇄ Двусторонняя
          </span>
          {/* Season badge (top-right) — updates with selection */}
          <span className="absolute top-4 right-4 z-[3] px-3 py-[0.4rem] bg-[rgba(13,13,13,0.8)] border border-[var(--olive-dark)] font-mono-brand text-[0.6rem] text-[var(--olive-light)] tracking-[1px] uppercase flex items-center gap-1.5">
            <span className="relative flex h-1.5 w-1.5" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[var(--olive)] opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[var(--olive)]" />
            </span>
            {SWATCHES.find((s) => s.id === cam)?.season}
          </span>
          {SWATCHES.map((s) => (
            <div
              key={s.id}
              className="absolute inset-0 transition-opacity duration-400"
              style={{
                background: PREVIEW_BG[s.id],
                opacity: cam === s.id ? 1 : 0,
              }}
            >
              <div
                className="absolute inset-0"
                style={{
                  backgroundImage:
                    "linear-gradient(rgba(0,0,0,0.12) 1px, transparent 1px)",
                  backgroundSize: "100% 3px",
                  mixBlendMode: "multiply",
                }}
              />
            </div>
          ))}
          {/* Description overlay (bottom) */}
          <div className="absolute bottom-0 left-0 right-0 p-4 z-[3] bg-gradient-to-t from-[rgba(0,0,0,0.85)] to-transparent">
            <div className="font-mono-brand text-[0.58rem] text-[var(--olive-light)] tracking-[1.5px] uppercase mb-0.5">
              Текущая расцветка
            </div>
            <div className="font-display text-[1.2rem] font-bold uppercase text-white leading-tight">
              {SWATCHES.find((s) => s.id === cam)?.label}
            </div>
            <div className="text-[0.78rem] text-[var(--text2)]">
              {SWATCHES.find((s) => s.id === cam)?.desc}
            </div>
          </div>
          {/* Zoom hint on hover */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[4] w-12 h-12 flex items-center justify-center bg-[rgba(13,13,13,0.7)] backdrop-blur-sm border border-[var(--olive)] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--olive-light)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35M11 8v6M8 11h6" />
            </svg>
          </div>
        </div>

        {/* Description + swatches */}
        <div>
          <h3 className="font-display text-[1.8rem] font-bold uppercase leading-[1.05]">
            Камуфляж +
            <br />
            коррекция фона
          </h3>
          <p className="text-base text-[var(--text2)] max-w-[560px] leading-[1.8] mt-4 mb-4">
            Накидки из материалов{" "}
            <b className="text-[var(--text)]">Оксфорд, Спанбонд, Спектра</b>{" "}
            скрывают силуэт и цвет в видимом диапазоне, а за счёт собственного
            нагрева размывают тепловой контур в ИК. Используются самостоятельно
            или поверх экранирующего слоя —{" "}
            <b className="text-[var(--text)]">
              не нарушают работу термоэкранирования
            </b>
            .
          </p>

          {/* Material tags */}
          <div className="flex flex-wrap gap-2 mb-4">
            {MATERIALS.map((m) => (
              <span
                key={m}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[var(--bg3)] border border-[var(--border-brand)] font-mono-brand text-[0.6rem] text-[var(--text2)] tracking-[1px] uppercase"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--olive)]" aria-hidden="true" />
                {m}
              </span>
            ))}
          </div>

          <div className="flex gap-2.5 my-6 flex-wrap">
            {SWATCHES.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setCam(s.id)}
                aria-pressed={cam === s.id}
                className={`cursor-pointer border-2 px-3 py-[0.4rem] flex items-center gap-2 bg-[var(--bg2)] text-[0.7rem] tracking-[1px] uppercase transition-all duration-300 ${
                  cam === s.id
                    ? "border-[var(--olive)] text-[var(--text)]"
                    : "border-[var(--border-brand)] text-[var(--text2)] hover:border-[var(--olive-dark)]"
                }`}
              >
                <i
                  className="w-3.5 h-3.5 rounded-[2px] inline-block"
                  style={{ background: SWATCH_ICON_BG[s.id] }}
                />
                {s.label}
              </button>
            ))}
          </div>

          <p className="text-[0.78rem] text-[var(--text3)]">
            * Превью расцветок схематичное. Реальные фото тканей подставим после
            согласования.
          </p>
        </div>
      </div>
    </section>
  );
}
