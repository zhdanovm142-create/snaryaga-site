"use client";

import { useEffect, useState } from "react";
import type { Product } from "@/data/products";
import { StarRating } from "./icons";
import { useFavorites } from "./use-favorites";
import { trackRecentlyViewed } from "./RecentlyViewed";
import RelatedProducts from "./RelatedProducts";
import BoughtTogether from "./BoughtTogether";
import SuitConfigurator, { getInitialTint } from "./SuitConfigurator";

interface Props {
  product: Product | null;
  onClose: () => void;
  onOrder: (productName: string) => void;
  /** Клик по сопутствующему товару — переключает модалку на него. */
  onSelectRelated?: (product: Product) => void;
}

/** Размерный ряд для подбора. */
const SIZES = ["S", "M", "L", "XL", "XXL"] as const;
type Size = (typeof SIZES)[number];

/** Категории, для которых предлагается выбор размера. */
const SIZABLE_CATEGORIES = new Set(["IR Suit", "Reversible Suit", "Full Kit"]);

function isLocalImage(src: string): boolean {
  return src.startsWith("/products/") || src.startsWith("/hero");
}

export default function ProductDetailModal({
  product,
  onClose,
  onOrder,
  onSelectRelated,
}: Props) {
  // Scroll-lock + Esc only when modal is open
  useEffect(() => {
    if (!product) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [product]);

  useEffect(() => {
    if (!product) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [product, onClose]);

  // Track recently viewed (side-effect only, no setState)
  useEffect(() => {
    if (product) {
      trackRecentlyViewed(product.id);
    }
  }, [product]);

  if (!product) return null;

  return (
    <div
      className="fixed inset-0 bg-[rgba(0,0,0,0.88)] backdrop-blur-[8px] z-[2000] flex items-center justify-center p-4 sm:p-8"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label={`Детали: ${product.name}`}
    >
      <div
        className="bg-[var(--bg2)] border border-[var(--border-brand)] rounded-[4px] max-w-[920px] w-full max-h-[92vh] overflow-y-auto relative"
        style={{ animation: "sn-modal-in 0.3s ease" }}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Закрыть"
          className="absolute top-4 right-4 z-10 w-9 h-9 bg-[var(--bg)] border border-[var(--border-brand)] flex items-center justify-center cursor-pointer text-[var(--text2)] text-[1.1rem] transition-all duration-300 hover:border-[var(--olive)] hover:text-[var(--text)]"
        >
          ×
        </button>

        {/* key={product.id} — при смене товара внутренний компонент перемонтируется,
            что сбрасывает useState без setState в effect. */}
        <ProductDetailContent
          key={product.id}
          product={product}
          onOrder={onOrder}
          onSelectRelated={onSelectRelated}
        />
      </div>
    </div>
  );
}

function ProductDetailContent({
  product,
  onOrder,
  onSelectRelated,
}: {
  product: Product;
  onOrder: (productName: string) => void;
  onSelectRelated?: (product: Product) => void;
}) {
  const { isFavorite, toggleFavorite, hydrated } = useFavorites();
  const [activeImg, setActiveImg] = useState<"main" | "hover">("main");
  const [size, setSize] = useState<Size | null>(null);
  const [variantLabel, setVariantLabel] = useState<string | null>(null);
  // Tint инициализируется первым вариантом (только для размерных категорий).
  const [tint, setTint] = useState<string>(() => getInitialTint(product.reversible));
  const fav = hydrated && isFavorite(product.id);

  const localImg = isLocalImage(product.images.main);
  const sizable = SIZABLE_CATEGORIES.has(product.category);

  const handleOrder = () => {
    // Собираем детали заказа: размер + расцветка (для размерных категорий).
    const details: string[] = [];
    if (size) details.push(`размер ${size}`);
    if (variantLabel) details.push(variantLabel);
    const detailStr = details.length > 0 ? ` (${details.join(", ")})` : "";
    onOrder(`${product.name}${detailStr}`);
  };

  // Стили для локальных (со своим фоном) vs CDN-прозрачных изображений.
  const imgWrapStyle: React.CSSProperties = localImg
    ? { backgroundColor: "var(--bg3)" }
    : {
        backgroundColor: "var(--olive)",
        backgroundImage:
          "linear-gradient(rgba(0,0,0,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.15) 1px, transparent 1px)",
        backgroundSize: "20px 20px",
      };
  const mainImgClass = localImg
    ? "absolute inset-0 w-full h-full object-cover"
    : "absolute w-[90%] h-[90%] object-contain mix-blend-multiply grayscale-[0.3] contrast-[1.2] brightness-[1.0]";
  const thumbImgClass = localImg
    ? "w-full h-full object-cover"
    : "w-full h-full object-contain mix-blend-multiply";

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
        {/* Image side */}
        <div className="relative bg-[var(--bg3)] p-6 sm:p-8">
          <div
            className="relative w-full aspect-square overflow-hidden flex items-center justify-center"
            style={imgWrapStyle}
          >
            <img
              src={activeImg === "main" ? product.images.main : product.images.hover}
              alt={activeImg === "main" ? product.alt.main : product.alt.hover}
              className={`${mainImgClass} transition-opacity duration-300`}
            />
            {/* Tint-оверлей — отражает выбранный вариант расцветки (только для костюмов) */}
            {sizable && (
              <div
                className="absolute inset-0 pointer-events-none transition-all duration-500 mix-blend-overlay"
                style={{ background: tint }}
                aria-hidden="true"
              />
            )}
            {localImg && (
              <div
                className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[rgba(0,0,0,0.45)] via-transparent to-transparent"
                aria-hidden="true"
              />
            )}
            {/* Подсказка о текущей расцветке */}
            {sizable && (
              <div className="absolute bottom-3 left-3 z-[2] px-2 py-1 bg-[rgba(13,13,13,0.8)] backdrop-blur-sm border border-[var(--olive-dark)] font-mono-brand text-[0.55rem] text-[var(--olive-light)] tracking-[1px] uppercase">
                {variantLabel ?? "Олива"}
              </div>
            )}
          </div>
          {/* Thumbnails */}
          <div className="flex gap-2 mt-3">
            <button
              type="button"
              onClick={() => setActiveImg("main")}
              aria-label="Вид 1"
              className={`relative w-16 h-16 overflow-hidden border-2 cursor-pointer transition-colors ${
                activeImg === "main"
                  ? "border-[var(--olive)]"
                  : "border-[var(--border-brand)] hover:border-[var(--olive-dark)]"
              }`}
            >
              <img
                src={product.images.main}
                alt={product.alt.main}
                className={thumbImgClass}
              />
            </button>
            <button
              type="button"
              onClick={() => setActiveImg("hover")}
              aria-label="Вид 2"
              className={`relative w-16 h-16 overflow-hidden border-2 cursor-pointer transition-colors ${
                activeImg === "hover"
                  ? "border-[var(--olive)]"
                  : "border-[var(--border-brand)] hover:border-[var(--olive-dark)]"
              }`}
            >
              <img
                src={product.images.hover}
                alt={product.alt.hover}
                className={thumbImgClass}
              />
            </button>
          </div>
        </div>

        {/* Info side */}
        <div className="p-6 sm:p-8 flex flex-col">
          <div className="flex items-center gap-3 mb-3 flex-wrap">
            <div className="font-mono-brand text-[0.62rem] text-[var(--olive)] tracking-[2px] uppercase">
              {product.category}
            </div>
            {product.tag && (
              <span
                className={`px-2 py-[0.2rem] text-[0.58rem] font-bold tracking-[1px] uppercase ${
                  product.tagKind === "new"
                    ? "bg-[var(--coyote)]"
                    : product.tagKind === "hit"
                      ? "bg-[#a85a3c]"
                      : "bg-[var(--olive)]"
                } text-white`}
              >
                {product.tag}
              </span>
            )}
          </div>

          <h2 className="font-display text-[1.7rem] sm:text-[2rem] font-bold uppercase leading-[1.05] mb-3">
            {product.name}
          </h2>

          {product.rating !== undefined && (
            <div className="flex items-center gap-2 mb-4">
              <StarRating value={product.rating} size={16} />
              <span className="font-mono-brand text-[0.8rem] text-[var(--text2)]">
                {product.rating.toFixed(1)}
              </span>
              {product.reviewsCount !== undefined && (
                <span className="text-[0.7rem] text-[var(--text3)]">
                  · {product.reviewsCount}{" "}
                  {pluralize(product.reviewsCount, [
                    "отзыв",
                    "отзыва",
                    "отзывов",
                  ])}
                </span>
              )}
            </div>
          )}

          <p className="text-[0.9rem] text-[var(--text2)] leading-[1.7] mb-6">
            {product.longDescription ?? product.description}
          </p>

          {/* Size selector — только для размерных категорий (костюмы/комплекты) */}
          {sizable && (
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <div className="font-mono-brand text-[0.65rem] text-[var(--olive)] tracking-[2px] uppercase">
                  Размер
                </div>
                <a
                  href="#size-guide"
                  className="text-[0.62rem] uppercase tracking-[1px] text-[var(--text3)] hover:text-[var(--olive-light)] transition-colors no-underline"
                >
                  Таблица размеров →
                </a>
              </div>
              <div
                className="flex flex-wrap gap-2"
                role="radiogroup"
                aria-label="Выбор размера"
              >
                {SIZES.map((s) => {
                  const selected = size === s;
                  return (
                    <button
                      key={s}
                      type="button"
                      role="radio"
                      aria-checked={selected}
                      onClick={() => setSize(s)}
                      className={`w-12 h-12 border font-mono-brand text-[0.85rem] font-bold tracking-[1px] cursor-pointer transition-all duration-200 ${
                        selected
                          ? "border-[var(--olive)] bg-[var(--olive)] text-white scale-105"
                          : "border-[var(--border-brand)] bg-[var(--bg3)] text-[var(--text2)] hover:border-[var(--olive-dark)] hover:text-[var(--text)]"
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
              {!size && (
                <p className="text-[0.65rem] text-[var(--text3)] mt-2">
                  * Выберите размер — он будет указан в заявке.
                </p>
              )}
            </div>
          )}

          {/* Конфигуратор расцветки — только для костюмов/комплектов */}
          {sizable && (
            <SuitConfigurator
              reversible={product.reversible}
              onVariantChange={(v) => {
                setVariantLabel(v.label);
                setTint(v.tint);
              }}
            />
          )}

          {/* Specs */}
          {product.specs && product.specs.length > 0 && (
            <div className="mb-6">
              <div className="font-mono-brand text-[0.65rem] text-[var(--olive)] tracking-[2px] uppercase mb-3">
                Характеристики
              </div>
              <dl className="grid grid-cols-2 gap-px bg-[var(--border-brand)] border border-[var(--border-brand)]">
                {product.specs.map((s) => (
                  <div
                    key={s.label}
                    className="bg-[var(--bg3)] p-3 flex flex-col gap-1"
                  >
                    <dt className="text-[0.62rem] uppercase tracking-[1px] text-[var(--text3)]">
                      {s.label}
                    </dt>
                    <dd className="text-[0.85rem] font-bold">{s.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          {/* Features */}
          {product.features && product.features.length > 0 && (
            <div className="mb-6">
              <div className="font-mono-brand text-[0.65rem] text-[var(--olive)] tracking-[2px] uppercase mb-3">
                Ключевые особенности
              </div>
              <ul className="space-y-3">
                {product.features.map((f) => (
                  <li key={f.title} className="flex gap-3">
                    <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center bg-[var(--bg3)] border border-[var(--border-brand)] text-base">
                      {f.icon}
                    </div>
                    <div>
                      <div className="font-display text-[0.95rem] font-bold uppercase tracking-[0.5px] mb-0.5">
                        {f.title}
                      </div>
                      <div className="text-[0.78rem] text-[var(--text2)] leading-[1.55]">
                        {f.desc}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Footer actions */}
          <div className="mt-auto pt-4 border-t border-[var(--border-brand)]">
            <div className="flex items-center justify-between gap-3 mb-3">
              <div>
                <div className="text-[0.62rem] uppercase tracking-[1px] text-[var(--text3)]">
                  Цена
                </div>
                <div className="font-mono-brand text-[1.1rem] font-bold">
                  {product.price}
                </div>
              </div>
              {product.leadTime && (
                <div className="text-right">
                  <div className="text-[0.62rem] uppercase tracking-[1px] text-[var(--text3)]">
                    Срок изготовления
                  </div>
                  <div className="text-[0.85rem] text-[var(--olive-light)] font-bold">
                    {product.leadTime}
                  </div>
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleOrder}
                disabled={sizable && !size}
                className={`flex-1 py-3 px-4 border text-[0.72rem] font-bold tracking-[2px] uppercase cursor-pointer transition-all duration-300 flex items-center justify-center gap-2 ${
                  sizable && !size
                    ? "border-[var(--border-brand)] bg-[var(--bg3)] text-[var(--text3)] cursor-not-allowed"
                    : "bg-[var(--olive)] border-[var(--olive)] text-white hover:bg-[var(--olive-light)]"
                }`}
              >
                Заказать{sizable && size ? ` · ${size}${variantLabel ? " · " + variantLabel : ""}` : ""}
              </button>
              <button
                type="button"
                onClick={() => toggleFavorite(product.id)}
                aria-pressed={fav}
                className={`px-4 py-3 border cursor-pointer transition-all duration-300 flex items-center gap-2 text-[0.68rem] font-bold tracking-[1px] uppercase ${
                  fav
                    ? "border-[var(--olive)] bg-[rgba(92,107,60,0.15)] text-[var(--olive-light)]"
                    : "border-[var(--border-brand)] text-[var(--text2)] hover:border-[var(--olive)] hover:text-[var(--olive-light)]"
                }`}
              >
                {fav ? "В избранном" : "В избранное"}
              </button>
            </div>
            {sizable && !size && (
              <p className="text-[0.62rem] text-[var(--text3)] mt-2 text-center">
                Сначала выберите размер, чтобы оформить заявку.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Cross-sell: «С этим товаром покупают» — комплект с чекбоксами */}
      <BoughtTogether product={product} onOrder={onOrder} onSelectRelated={onSelectRelated} />

      {/* Related products — только если есть колбэк переключения */}
      {onSelectRelated && <RelatedProducts currentId={product.id} onSelect={onSelectRelated} />}
    </div>
  );
}

function pluralize(n: number, forms: [string, string, string]) {
  const a = Math.abs(n) % 100;
  const b = a % 10;
  if (a > 10 && a < 20) return forms[2];
  if (b > 1 && b < 5) return forms[1];
  if (b === 1) return forms[0];
  return forms[2];
}
