"use client";

import { useCallback, useEffect, useState } from "react";
import { StarRating } from "./icons";

interface Review {
  name: string;
  role: string;
  rating: number;
  text: string;
  product?: string;
  date: string;
  source: "VK" | "WhatsApp" | "Email" | "Сайт";
  verified?: boolean;
  /** Фото от покупателя (локальные пути к /public/products/). */
  photos?: string[];
}

const REVIEWS: Review[] = [
  {
    name: "Алексей М.",
    role: "Контрактник",
    rating: 5,
    text: "Брали «Фантом-50» на выходы. По тепловизору проверить удалось — реально «холодный» объект. Швы аккуратные, ничего не оторвалось за 3 месяца.",
    product: "Рюкзак «Фантом-50»",
    date: "Март 2025",
    source: "WhatsApp",
    verified: true,
    photos: ["/products/backpack-cover.png"],
  },
  {
    name: "Гранит",
    role: "Командир взвода",
    rating: 5,
    text: "Заказывали партию рюкзаков 100L для эвакуации снаряжения. Качество ткани, швов, фурнитуры — выше ожиданий. Сроки выдержали.",
    product: "Рюкзак «Бастион-100»",
    date: "Февраль 2025",
    source: "VK",
    verified: true,
  },
  {
    name: "Дмитрий К.",
    role: "Волонтёр",
    rating: 5,
    text: "Покупал накидку «Мох» на свою машину — размытие силуэта в ИК работает. Отдельное спасибо команде за быструю отправку.",
    product: "Накидка «Мох»",
    date: "Январь 2025",
    source: "Сайт",
  },
  {
    name: "Сергей В.",
    role: "Охотник",
    rating: 4,
    text: "Брал «Тень-20» для охотничьих выходов в холодное время. Спинка удобная, ИК-защита работает. Минус — нет отдельного кармана под очки.",
    product: "Рюкзак «Тень-20»",
    date: "Декабрь 2024",
    source: "Email",
    verified: true,
    photos: ["/products/backpack-cover.png"],
  },
  {
    name: "Андрей П.",
    role: "Тактик",
    rating: 5,
    text: "Костюм «Меркурий» показал себя отлично в ночных задачах. Ткань дышит, ИК-экран держит. Рекомендую.",
    product: "Костюм «Меркурий»",
    date: "Ноябрь 2024",
    source: "WhatsApp",
    verified: true,
    photos: ["/products/burger-big-front.png", "/products/burger-reversible.png"],
  },
];

// Распределение оценок (для полоски в шапке). Сумма = 38 отзывов.
const RATING_DIST = [
  { stars: 5, count: 31 },
  { stars: 4, count: 5 },
  { stars: 3, count: 2 },
  { stars: 2, count: 0 },
  { stars: 1, count: 0 },
];
const TOTAL_REVIEWS = 38;
const AVG_RATING = 4.8;

const SOURCE_ICON: Record<Review["source"], string> = {
  VK: "ВК",
  WhatsApp: "WA",
  Email: "✉",
  Сайт: "С",
};

const AVATAR_COLORS = ["#5c6b3c", "#8b7355", "#3d4728", "#6b6040", "#4a3d28"];

export default function ReviewsCarousel() {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const count = REVIEWS.length;

  const next = useCallback(() => {
    setActive((i) => (i + 1) % count);
  }, [count]);

  const prev = useCallback(() => {
    setActive((i) => (i - 1 + count) % count);
  }, [count]);

  // Авто-прокрутка каждые 5 секунд, останавливается при наведении
  useEffect(() => {
    if (paused) return;
    const t = setInterval(next, 5000);
    return () => clearInterval(t);
  }, [paused, next]);

  const current = REVIEWS[active];

  return (
    <section id="reviews" className="sn-section">
      <header className="reveal mb-16">
        <div className="font-mono-brand text-[0.68rem] text-[var(--olive)] tracking-[3px] uppercase mb-4 flex items-center gap-4 before:content-[''] before:w-[30px] before:h-px before:bg-[var(--olive)]">
          Отзывы
        </div>
        <div className="flex justify-between items-end flex-wrap gap-8">
          <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-bold uppercase tracking-[-1px] leading-[1.05]">
            Что говорят
            <br />
            пользователи
          </h2>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="font-display text-[2.4rem] font-bold text-[var(--olive-light)] leading-none">
                {AVG_RATING.toFixed(1)}
              </div>
              <div className="text-[0.7rem] uppercase tracking-[2px] text-[var(--text3)] mt-1">
                средняя оценка
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <StarRating value={AVG_RATING} size={18} />
              <div className="text-[0.7rem] text-[var(--text3)]">
                {TOTAL_REVIEWS} отзывов
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Распределение оценок */}
      <div className="reveal mb-10 max-w-[560px] ml-auto">
        {RATING_DIST.map((d) => {
          const pct = TOTAL_REVIEWS > 0 ? Math.round((d.count / TOTAL_REVIEWS) * 100) : 0;
          return (
            <div key={d.stars} className="flex items-center gap-3 py-1">
              <span className="font-mono-brand text-[0.7rem] text-[var(--text2)] w-8 flex items-center gap-0.5">
                {d.stars}<span className="text-[var(--olive-light)] text-[0.6rem]">★</span>
              </span>
              <div className="flex-1 h-1.5 bg-[var(--bg3)] border border-[var(--border-brand)] overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[var(--olive-dark)] to-[var(--olive-light)] transition-all duration-700"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <span className="font-mono-brand text-[0.65rem] text-[var(--text3)] w-10 text-right">
                {d.count}
              </span>
            </div>
          );
        })}
      </div>

      <div
        className="reveal relative"
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
      >
        {/* Carousel viewport */}
        <div className="relative overflow-hidden border border-[var(--border-brand)] bg-[var(--bg2)]">
          <div
            className="flex transition-transform duration-700 ease-out"
            style={{
              transform: `translateX(-${active * 100}%)`,
              transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)",
            }}
          >
            {REVIEWS.map((r, i) => (
              <article
                key={i}
                className="min-w-full p-8 sm:p-12 flex flex-col gap-6"
                aria-hidden={i !== active}
              >
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-4">
                    <div
                      className="w-14 h-14 rounded-full flex items-center justify-center font-display font-bold text-white text-xl"
                      style={{ backgroundColor: AVATAR_COLORS[i % AVATAR_COLORS.length] }}
                      aria-hidden="true"
                    >
                      {r.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-display text-[1.1rem] font-bold uppercase tracking-[0.5px] flex items-center gap-2">
                        {r.name}
                        {r.verified && (
                          <span
                            className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-[rgba(92,107,60,0.18)] border border-[var(--olive-dark)] text-[var(--olive-light)] text-[0.5rem] tracking-[1px] uppercase font-mono-brand"
                            title="Проверенная покупка"
                          >
                            <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                              <path d="M20 6L9 17l-5-5" />
                            </svg>
                            Проверено
                          </span>
                        )}
                      </div>
                      <div className="text-[0.7rem] text-[var(--text3)] uppercase tracking-[1px]">
                        {r.role}
                      </div>
                    </div>
                  </div>
                  <StarRating value={r.rating} size={18} />
                </div>
                <blockquote className="text-[1.05rem] text-[var(--text)] leading-[1.7] italic">
                  <span className="text-[var(--olive-light)] text-[1.6rem] leading-none mr-1" aria-hidden="true">«</span>
                  {r.text}
                  <span className="text-[var(--olive-light)] text-[1.6rem] leading-none ml-1" aria-hidden="true">»</span>
                </blockquote>
                {/* Фото от покупателя */}
                {r.photos && r.photos.length > 0 && (
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[0.6rem] uppercase tracking-[2px] text-[var(--text3)] mr-1">
                      📷 Фото покупателя:
                    </span>
                    {r.photos.map((p, idx) => (
                      <button
                        key={idx}
                        type="button"
                        aria-label={`Фото ${idx + 1} от ${r.name}`}
                        className="group relative w-16 h-16 overflow-hidden border border-[var(--border-brand)] hover:border-[var(--olive)] transition-colors cursor-pointer bg-[var(--bg3)]"
                      >
                        <img
                          src={p}
                          alt={`Фото ${idx + 1} от ${r.name}`}
                          loading="lazy"
                          className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                        />
                        <span className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-[rgba(13,13,13,0.6)]">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--olive-light)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                            <circle cx="11" cy="11" r="8" />
                            <path d="M21 21l-4.35-4.35M11 8v6M8 11h6" />
                          </svg>
                        </span>
                      </button>
                    ))}
                  </div>
                )}
                {r.product && (
                  <div className="pt-4 border-t border-[var(--border-brand)] flex items-center gap-2 flex-wrap">
                    <span className="text-[0.6rem] uppercase tracking-[2px] text-[var(--text3)]">
                      Товар:
                    </span>
                    <span className="font-mono-brand text-[0.72rem] text-[var(--olive-light)] px-2 py-1 bg-[rgba(92,107,60,0.08)] border border-[var(--olive-dark)]">
                      {r.product}
                    </span>
                    <span className="ml-auto flex items-center gap-2 text-[0.62rem] uppercase tracking-[1px] text-[var(--text3)]">
                      <span className="px-1.5 py-0.5 border border-[var(--border-brand)] font-mono-brand">
                        {SOURCE_ICON[r.source]}
                      </span>
                      {r.date}
                    </span>
                  </div>
                )}
              </article>
            ))}
          </div>

          {/* Prev / Next buttons */}
          <button
            type="button"
            onClick={prev}
            aria-label="Предыдущий отзыв"
            className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-[rgba(13,13,13,0.7)] backdrop-blur-sm border border-[var(--border-brand)] text-[var(--text2)] cursor-pointer transition-all duration-300 hover:border-[var(--olive)] hover:text-[var(--olive-light)] hover:bg-[rgba(13,13,13,0.9)]"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 18l-6-6 6-6" />
            </svg>
          </button>
          <button
            type="button"
            onClick={next}
            aria-label="Следующий отзыв"
            className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-[rgba(13,13,13,0.7)] backdrop-blur-sm border border-[var(--border-brand)] text-[var(--text2)] cursor-pointer transition-all duration-300 hover:border-[var(--olive)] hover:text-[var(--olive-light)] hover:bg-[rgba(13,13,13,0.9)]"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M9 18l6-6-6-6" />
            </svg>
          </button>
        </div>

        {/* Dots / progress */}
        <div className="flex items-center justify-center gap-2 mt-6">
          {REVIEWS.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setActive(i)}
              aria-label={`Отзыв ${i + 1}`}
              aria-pressed={i === active}
              className={`h-2 transition-all duration-300 cursor-pointer border-none ${
                i === active
                  ? "w-8 bg-[var(--olive-light)]"
                  : "w-2 bg-[var(--border-brand)] hover:bg-[var(--olive-dark)]"
              }`}
            />
          ))}
        </div>

        {/* Counter */}
        <div className="text-center mt-3 font-mono-brand text-[0.65rem] uppercase tracking-[2px] text-[var(--text3)]">
          {String(active + 1).padStart(2, "0")} / {String(count).padStart(2, "0")}
          {paused && " · пауза"}
        </div>
      </div>
    </section>
  );
}
